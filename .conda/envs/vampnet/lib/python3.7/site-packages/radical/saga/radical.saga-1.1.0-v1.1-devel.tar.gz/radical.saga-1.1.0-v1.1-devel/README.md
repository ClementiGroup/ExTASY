RADICAL-SAGA
============

[![Build Status](https://travis-ci.org/radical-cybertools/radical.saga.svg?branch=devel)](https://travis-ci.org/radical-cybertools/radical.saga)


A light-weight access layer for distributed computing infrastructure 

  www:  http://radical-cybertools.github.io/radical.saga/
  wiki: https://github.com/radical-cybertools/radical.saga/wiki


Unit Tests
----------

The unit tests for radical.saga can be found in the tests/ subdirectory.
Instructions how to tun the tests are in tests/README.md.
 
RADICAL-SAGA requires Python version >= 2.7 and < 3.x.



