
__author__    = "Radical.Utils Development Team"
__copyright__ = "Copyright 2018, RADICAL"
__license__   = "GPL"


# ------------------------------------------------------------------------------
#
class Queue(object):
    pass


# ------------------------------------------------------------------------------

