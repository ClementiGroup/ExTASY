#!/bin/sh

n=$1
o=$2
s=$3
t=$4

sleep $t
echo "NS $n [$o/$s] [$t]"

