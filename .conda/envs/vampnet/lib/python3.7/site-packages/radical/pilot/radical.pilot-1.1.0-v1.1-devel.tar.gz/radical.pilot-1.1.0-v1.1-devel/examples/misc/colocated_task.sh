#!/bin/sh

bag=$1
size=$2
tid=$3

sleep 3
echo "Bag $bag ($size): $tid"

