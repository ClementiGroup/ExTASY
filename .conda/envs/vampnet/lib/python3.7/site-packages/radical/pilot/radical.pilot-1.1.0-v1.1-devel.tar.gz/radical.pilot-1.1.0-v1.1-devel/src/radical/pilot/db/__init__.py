""" Database abstraction layer
"""

from .database import *

